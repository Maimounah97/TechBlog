import FileBase64 from 'react-file-base64';
import React, { useState } from "react";
import { Link, useHistory } from "react-router-dom";

import AOS from 'aos'
import 'aos/dist/aos.css'


const Form = (props) => {
    AOS.init({ duration: 3000 });
    // const[errors , setErrors] = useState([])

    const [success, setSuccess] = useState(false);
    const [title, setTitle] = useState(props.initTitle);
    const [article, setArticle] = useState(props.initArticle);
    const [summary, setSummary] = useState(props.initSummary);
    const [image, setImage] = useState(props.initImage);
    const [category, setCategory] = useState(props.initCategory);
    const categories = ["Artificial intelligence", "Cyber Security", "Data Science", "Web Development", "Mobile Development"];
    const history = useHistory();
    const onSubmitHandler = (e) => {
        e.preventDefault();
        props.onSubmitHandler({
            title,
            category,
            image,
            summary,
            article
        });
    };

    //handle image

    const handleImage = (e) => {
        const file = e.target.files[0];
        setFileToBase(file);
        console.log(file)
    }
    const setFileToBase = (file) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onloadend = () => {
            setImage(reader.result)
        }
    }

    return (
        <>
            <div className='m-3'>
                {props.errors.map((errMsg, i) => (
                    <p key={i} className="alert alert-danger">
                        {" "}
                        {errMsg}{" "}
                    </p>
                ))}
            </div>
            <form onSubmit={onSubmitHandler}>
                <div className="mt-5">
                    <div className="text-start">
                        <div className="row d-flex align-items-start">
                            <p className="col">
                                <label>
                                    Title <span className="text-danger">*</span>:
                                </label>
                                <input
                                    name="title"
                                    type="text"
                                    onChange={(e) => setTitle(e.target.value)}
                                    value={title}
                                    className="form-control"
                                />
                            </p>

                            <p className="col">
                                <label>
                                    Category <span className="text-danger">*</span> :
                                </label>
                                <select
                                    onChange={(e) => setCategory(e.target.value)}
                                    value={category}
                                    className="form-select"
                                >
                                    <option>Select category</option>
                                    {categories.map((category, index) => (
                                        <option key={index} value={category}>
                                            {category}
                                        </option>
                                    ))}
                                </select>
                            </p>

                            <p className="col">
                                <label>
                                    Image <span className="text-danger">*</span>:
                                </label>
                                <input
                                    name="image"
                                    type="file"
                                    onChange={handleImage}
                                    className="form-control"
                                />
                                <small className='text-danger'>image size less than 100KB</small>
                            </p>
                        </div>
                        <div className='row'>
                            <img className='img-rounded' src={image} alt="" style={{ "width": "600px", "height": "300px", "border-radius": "25px" }}></img>
                        </div>
                        <div className="row">
                            <p className="col">
                                <label>
                                    Summary <span className="text-danger">*</span> :
                                </label>
                                <textarea
                                    name="name"
                                    type="text"
                                    rows="2"
                                    onChange={(e) => setSummary(e.target.value)}
                                    value={summary}
                                    className="form-control"
                                />
                            </p>

                        </div>
                        <div className="row">
                            <p className="col">
                                <label>
                                    Article <span className="text-danger">*</span> :
                                </label>
                                <textarea
                                    name="name"
                                    type="text"
                                    rows="5"
                                    onChange={(e) => setArticle(e.target.value)}
                                    value={article}
                                    className="form-control"
                                />
                            </p>

                        </div>

                    </div>

                </div>

                <div className="d-flex justify-content-center mt-5">
                    <div className="text-center">
                        <input
                            type="submit"
                            className="btn btn-success rounded-pill"
                        />
                    </div>
                    <button onClick={(e) => { history.goBack() }} className="btn btn-outline-secondary rounded-pill ms-2 ">
                        {" "}
                        Cancel{" "}
                    </button>
                </div>
            </form>
            <br />

        </>
    );
};

export default Form;