import logo from './logo.svg';
import './App.css';
import { BrowserRouter ,Switch ,Route , Link} from "react-router-dom";
import RegisterForm from './Components/RegisterForm';
import LoginForm from './Components/LoginForm';
import CreateBlog from './Components/CreateBlog';
import Home from './Components/Home';
import Category from './Components/Category';
import AddImageInSlider from './Components/AddImageInSlider';
import AdminDashboard from './Components/AdminDashboard';
import BlogDetailes from './Components/BlogDetailes';
import EditBlog from './Components/EditBlog';


function App() {
  // c array
  return (
    <div className="App">
      <BrowserRouter>
        <Switch>
        <Route exact path="/">
            <Home/>
          </Route>
        <Route exact path="/register">
            <RegisterForm/>
          </Route>
          <Route exact path="/login">
            <LoginForm/>
          </Route>
          <Route exact path="/addBlog">
            <CreateBlog/>
          </Route>
          <Route exact path="/addImageInSlider">
            <AddImageInSlider/>
          </Route>
          <Route exact path="/adminDashboard">
            <AdminDashboard/>
          </Route>
          <Route exact path="/Artificial Intelligence"> 
            <Category c={'Artificial Intelligence'}/>
          </Route>
          <Route exact path="/Cyber Security"> 
            <Category c={'cyber security'}/>
          </Route>
          <Route exact path="/Data Science"> 
            <Category c={'Data Science'}/>
          </Route>
          <Route exact path="/Web Development"> 
            <Category c={'Web Development'}/>
          </Route>
          <Route exact path="/Mobile Development"> 
            <Category c={'Mobile Development'}/>
          </Route>
          <Route exact path="/blog/:id"> 
            <BlogDetailes/>
          </Route>
          <Route exact path="/blog/:id/edit">
            <EditBlog/>
          </Route>
          </Switch>
      </BrowserRouter>
      
    </div>
  );
}

export default App;