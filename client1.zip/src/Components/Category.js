import React, { useState, useEffect } from 'react'
import { Link, useHistory } from "react-router-dom";
import axios from "axios";
import '../Styles/Home.css';
import '../Styles/Card.css';
import Card from './Card';
import LoginNav from './LoginNav';
import Slider from './Slider';
import Aos from 'aos';
import "aos/dist/aos.css";



const Category = ({ c }) => {
    Aos.init({ duration: 3000 });
    const [blogs, setBlogs] = useState([]);
    const [detailes, setDetailes] = useState(false);
    const [oneBlog, setOneBlog] = useState({});
    const history = useHistory();

    useEffect(() => {
        axios
            .get("http://localhost:8000/api/blogs")
            .then((res) => {
                console.log(res);
                setBlogs(res.data.blogs);
                console.log(c)
            })
            .catch((err) => console.error(err));
    }, []);

    return (
        <>
            <LoginNav />
            <div className="body">

                <div className='container'>
                    <Slider />

                    <div className="row">

                        <div className="col-8 blogs-container">
                            <h2 className="text-capitalize font-weight-bold">{c}</h2>
                            <hr />
                            <div className="row">
                                {blogs.filter((blog, index) => blog.category == c).map((b, i) => (
                                    <div key={i}>
                                        <Card title={b.title} category={b.category} image={b.image} />
                                    </div>
                                ))}


                            </div>
                        </div>
                        <div className="col-2 categories-container" >
                            <div data-aos="fade-up" className='title fw-bold fs-2'>
                                Categories
                            </div>
                            <div data-aos="fade-up" className='category'>
                                <Link to='/Artificial intelligence'><p className='category-title'>Artificial intelligence</p></Link>
                                {/* <a  href="#" onClick={(e) => { history.push('/Artificial intelligence') }} class="btn btn-info" role="button" >Artificial intelligence</a> */}
                            </div>
                            <br />
                            <div data-aos="fade-up" className='category'>
                                <Link to='/Cyber Security'><p className='category-title'>Cyber Security</p></Link>
                            </div>
                            <br />
                            <div data-aos="fade-up" className='category'>
                                <Link to='/Data Science'><p className='category-title'>Data Science</p></Link>
                            </div>
                            <br />
                            <div data-aos="fade-up" className='category'>
                                <Link to='/Web Development'><p className='category-title'>Web Development</p></Link>
                            </div>
                            <br />
                            <div data-aos="fade-up" className='category' style={{ "marginBottom": "100px" }}>
                                <Link to='/Mobile Development'><p className='category-title'>Mobile Development</p></Link>
                            </div>
                            <br />
                        </div>

                    </div>
                </div>
            </div>

        </>
    )
}

export default Category


