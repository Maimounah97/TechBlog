import FileBase64 from 'react-file-base64';
import React, { useState, useEffect } from 'react'
import { useHistory } from 'react-router'
import axios from 'axios';
import { Link } from "react-router-dom";
import Form from '../Components/Form';
import LoginNav from './LoginNav'


const CreateBlog = () => {

    // const {id} = useParams();
    const history = useHistory();
    const [blogs, setBlogs] = useState([]);
    const [errors, setErrors] = useState([])
    const [success, setSuccess] = useState(false)
    const userId = localStorage.getItem("userId")
    const [user, setUser] = useState({});
    const [userRole, setUserRole] = useState();

    useEffect(() => {
        //----------userInfo----------
        axios.get("http://localhost:8000/api/user/" + userId)
            .then((res) => {
                setUser(res.data)
                console.log(res.data.role)
                setUserRole(res.data.role)
            })
            .catch((err) => console.error(err));

    }, []);


    const create = (blog) => {
        axios.get('http://localhost:8000/api/blogs')
            .then(res => {
                setBlogs(res.data)

            });
        setSuccess(false)
        setErrors([])
        axios.post('http://localhost:8000/api/blog/new', blog)
            .then(res => {
                console.log(res)
                setBlogs([...blogs, res.data]);
                setSuccess(true)
                history.goBack()
            })
            .catch(err => {
                console.log(err)
                const data = err.response.data
                const errorMessages = [];
                if ("errors" in data) {
                    for (let field in data.errors) {
                        const validationError = data.errors[field]
                        errorMessages.push(validationError.message)
                    }
                }
                setErrors(errorMessages)
            })
    }



    return (
        <>
            <LoginNav />
            <div className='body'>

                <div className='container pt-5 col-7 '>
                    <div className='form-border'>
                        {(userRole == "admin") ?
                            <div className='container mt-5'>

                                {success && <p className='alert alert-success'>Blog has been successafully Add</p>}

                                <div className='d-flex justify-content-between mt-3'>
                                    <div className='text-secondary'><h5>Add Blog</h5></div>
                                    <div onClick={() => { history.goBack() }} className="btn btn-outline-secondary rounded-pill ms-2 ">Back to Dashboard</div>
                                </div>
                                <Form onSubmitHandler={create} errors={errors} initTitle="" initArticle="" initSummary="" initImage="" initCategory="" />
                            </div>
                            :
                            <div className='test-light'> For authorized users only
                                <div><Link to="/" className="btn btn-outline-secondary rounded-pill ms-2 mt-4">Back to HOME</Link></div>
                            </div>
                        }
                    </div>
                </div>
            </div>
        </>
    )
}







export default CreateBlog