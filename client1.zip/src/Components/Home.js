import React, { useState, useEffect } from 'react'
import axios from "axios";
import LoginNav from './LoginNav'
import Card from './Card';
import '../Styles/Home.css';
import '../Styles/Card.css';
import { useHistory } from 'react-router'
import { Link } from "react-router-dom";
import Slider from './Slider';
import Blogs from './Blogs';

const Home = () => {

    return (
        <>
            <LoginNav />

            <div className="body">

                <div className='container'>
                    <div className='siderl'>
                        <Slider />
                    </div>


                    <div className="row">

                        <div className="col-8 blogs-container">
                            <div className="row">
                                <Blogs />
                            </div>
                        </div>
                        <div className="col-3 categories-container mb-6" >
                            <div className='title fw-bold fs-2'>
                                Categories
                            </div>
                            <div data-aos="fade-up" className='category'>
                                <Link to='/Artificial Intelligence'><p className='category-title'>Artificial Intelligence</p></Link>
                            </div>
                            <br />
                            <div data-aos="fade-up" className='category'>
                                <Link to='/Cyber Security'><p className='category-title'>Cyber Security</p></Link>
                            </div>
                            <br />
                            <div data-aos="fade-up" className='category'>
                                <Link to='/Data Science'><p className='category-title'>Data Science</p></Link>
                            </div>
                            <br />
                            <div data-aos="fade-up" className='category'>
                                <Link to='/Web Development'><p className='category-title'>Web Development</p></Link>
                            </div>
                            <br />
                            <div data-aos="fade-up" className='category' style={{ "marginBottom": "100px" }}>
                                <Link to='/Mobile Development'><p className='category-title'>Mobile Development</p></Link>
                            </div>
                            <br />

                        </div>
                    </div>




                </div>
            </div>
        </>
    )
}

export default Home