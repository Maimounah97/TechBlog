import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useHistory } from "react-router-dom";
import '../Styles/Nav.css';
import logout from '../assets/logut-bg2.png';

const LoginNav = () => {
    const [user, setUser] = useState({});
    const history = useHistory();
    const [userRole, setUserRole] = useState();
    const userId = localStorage.getItem("userId")

    useEffect(() => {
      //----------userInfo----------
      axios
        .get("http://localhost:8000/api/user/" + userId)
        .then((res) => {
          console.log(res.data.role)
          setUserRole(res.data.role)
          setUser(res.data)
        })
        .catch((err) => console.error(err));

    }, []);

    const logoutHandler = () =>{
        console.log("logout clicked")
        localStorage.removeItem("userId");
        history.push("/")

    }
    //---------------------user nav------------------------

    if (userRole == "user") {
        return (
            <>

              
            <nav  style={{"zIndex" : "9999999000000000000000000000000000"}}>  
            <div className="mb-5 navbar-brand fw-bold"><Link to="/" >TechBlog</Link></div>
                <ul>
                    <li><Link to="/">HOME</Link></li>
                    <li><img src={logout} onClick={logoutHandler} className="logout"/></li>
                </ul>
            </nav>
            
        </>
        )
      }
//---------------------admin nav------------------------
      if (userRole == "admin") {
        
        return (
            <>
                <nav style={{"zIndex" : "999999999000000000000000000000000000"}}> 
                <div className="mb-5 navbar-brand fw-bold"><Link to="/" >TechBlog</Link></div>
                    <ul className="mb-5">
                        <li><Link to="/" >HOME</Link></li>
                        <li><Link to="/addBlog" >CREATE BLOG</Link></li>
                        <li><Link to="/adminDashboard" >ADMIN DASHBOARD</Link></li>
                        <li><img src={logout} onClick={logoutHandler} className="logout"/></li>
                    </ul>
                </nav>
                
            </>
        )
      }
 //---------------------user nav------------------------
      if (userId !== null) {
        // setUserFlag(true)
        return (
            <>

            <nav className="bg-dark" style={{"zIndex" : "9999999000000000000000000000000000"}}>
            <div className="mb-5 navbar-brand fw-bold"><Link to="/" >TechBlog</Link></div>
                <ul>
                    <li><Link to="/">HOME</Link></li>
                    <li><img src={logout} onClick={logoutHandler} className="logout"/></li>

                </ul>
            </nav>
    
                
                
            </>
        )
      }

//---------------------guest user nav------------------------
      if (userId === null) {
        return (
            <>

            <nav className="nav" style={{"zIndex" : "9999999900000000000000000000000"}}>
            <div className="mb-5 navbar-brand fw-bold"><Link to="/" >TechBlog</Link></div>
                <ul>
                    <li><Link to="/">HOME</Link></li>
                    
                    <li><Link to="/login" className="text-warning">LOGIN</Link></li>
                    
                    <li><Link to="/logout" className="text-danger"><img src={''} className="logout"/></Link></li>
                </ul>
            </nav>
    
                
                
            </>
        )
      }


  

   
}

export default LoginNav