import React, { useState, useEffect } from 'react'
import axios from "axios";
import { useHistory } from 'react-router'
import { Link } from "react-router-dom";
import '../Styles/Home.css';
import HeroSlider, { Slide, Nav, OverlayContainer } from "hero-slider";




const Slider = () => {
    const history = useHistory();
    const [slide, setSlide] = useState([]);
    useEffect(() => {
        axios.get("http://localhost:8000/api/slide")
            .then((res) => {
                console.log(res.data.slide);
                setSlide(res.data.slide);
                console.log(slide);
            })
            .catch((err) => console.error(err));
    }, []);

    return (
        <HeroSlider
            slidingAnimation="left_to_right"
            orientation="horizontal"
            initialSlide={1}
            onBeforeChange={(previousSlide, nextSlide) =>
                console.log("onBeforeChange", previousSlide, nextSlide)
            }
            onChange={nextSlide => console.log("onChange", nextSlide)}
            onAfterChange={nextSlide => console.log("onAfterChange", nextSlide)}
            style={{
                backgroundColor: "rgba(0, 0, 0, 0.33)"
            }}
            settings={{
                slidingDuration: 250,
                slidingDelay: 100,
                shouldAutoplay: true,
                shouldDisplayButtons: true,
                autoplayDuration: 5000,
                height: "100vh"
            }}
        >
            <div className="container">
                <div className="Wrapper">
                    <div className="title"></div>
                    <div className="subtitle"></div>
                </div>
            </div>
            {slide.map((image, i) => (
                <Slide key={i}
                    background={{
                        backgroundImageSrc: image.image,
                        backgroundAttachment: "fixed"
                    }}
                />

            ))}



            <Nav />
        </HeroSlider>
    );
};

export default Slider;