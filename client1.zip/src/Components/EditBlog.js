import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useHistory, useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import Form from './Form';
import LoginNav from './LoginNav'


const EditBlog = (props) => {


    const { id } = useParams();
    const [blog, setBlog] = useState({});
    const [loaded, setLoaded] = useState(false);
    const [errors, setErrors] = useState([]);
    const [isLoading, setLoading] = useState(true);
    const [success, setSuccess] = useState(false)
    const [userRole, setUserRole] = useState();
    const userId = localStorage.getItem("userId")
    const [user, setUser] = useState({});


    const history = useHistory()
    useEffect(() => {
        axios
            .get("http://localhost:8000/api/user/" + userId)
            .then((res) => {
                console.log(res.data.role)
                setUserRole(res.data.role)
                setUser(res.data)
            })
            .catch((err) => console.error(err));
        axios.get('http://localhost:8000/api/blog/' + id)
            .then(res => {
                console.log(res.data)
                setBlog(res.data);
                setLoading(false);
                setLoaded(true);
            })
            .catch(err => {
                setLoading(false);
                console.error("We have an error");
            })
    }, [])


    const updateBlog = blog => {
        axios.put('http://localhost:8000/api/blog/' + id, blog)
            .then(res => {
                console.log(res)
                history.goBack()
            })
            .catch(err => {
                const errorResponse = err.response.data.errors; // Get the errors from err.response.data
                const errorArr = []; // Define a temp error array to push the messages in
                for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
                    errorArr.push(errorResponse[key].message)
                }
                // Set Errors
                setErrors(errorArr);
            })
    }



    //In our return

    if (isLoading) {
        return <div>...Loading</div>;
    }
    if (userRole == "user" || userRole == "") {
        return (
            <div>
                <h1 >Welcome {user.name}</h1>
                <div> For authorized users only
                    <div><Link to="/" className="btn btn-outline-secondary rounded-pill ms-2 ">Back to HOME</Link></div>
                </div>
            </div>
        )
    }


    return (
        <>
            <LoginNav />
            <div className='body'>
                <div className='container pt-5 col-7 '>
                    <div className='form-border'>
                        {(userRole == "admin") ?
                            <div className='container mt-5'>

                                {success && <p className='alert alert-success'>Blog has been successafully Updated</p>}

                                <div className='d-flex justify-content-between mt-3'>
                                    <div className='text-secondary'><h5>Edit Blog</h5></div>
                                    <div onClick={() => { history.goBack() }} className="btn btn-outline-secondary rounded-pill ms-2 ">Back to Dashboard</div>
                                </div>

                                <Form onSubmitHandler={updateBlog} errors={errors} initTitle={blog.title} initBlog={blog.article} initSummary={blog.summary} initImage={blog.image} initCategory={blog.category}
                                />
                            </div>
                            :
                            <div className='test-light'> For authorized users only
                                <div><Link to="/" className="btn btn-outline-secondary rounded-pill ms-2 mt-4">Back to HOME</Link></div>
                            </div>
                        }

                    </div>
                </div>

            </div>
        </>

    )
}


export default EditBlog;

