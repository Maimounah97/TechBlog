import React, { useState, useEffect } from 'react'
import axios from "axios";
import Card from './Card';
import '../Styles/Card.css';
import { useHistory } from 'react-router'
import { Link } from "react-router-dom";

const Blogs = () => {
    const history = useHistory();
    const [blogs, setBlogs] = useState([]);


    useEffect(() => {
        axios.get("http://localhost:8000/api/blogs")
            .then((res) => {
                console.log(res.data.blogs);
                setBlogs(res.data.blogs);
                console.log(blogs);
            })
            .catch((err) => console.error(err));
    }, []);

    return (
        <>
            {blogs.map((blog, i) => (
                <Card title={blog.title} category={blog.category} image={blog.image} summary={blog.summary} blogId={blog._id} />
            ))}
        </>
    )
}

export default Blogs