import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams, useHistory, Link } from "react-router-dom";
import LoginNav from './LoginNav'
// import './DisplayDetailes.css';



const linkStyle = {
    justifyContent: "end",
    display: "flex",
    margin: "20px",
};

const BlogDetailes = (props) => {
    const [blog, setBlog] = useState({});
    const { id } = useParams();
    const history = useHistory();
    const [user, setUser] = useState({});
    const [flag, setFlag] = useState(false)
    const userId = localStorage.getItem("userId")


    const logoutHandler = () => {
        localStorage.removeItem("userId");
        history.push("/login")
    }


    useEffect(() => {
        axios
            .get("http://localhost:8000/api/blog/" + id)
            .then((res) => {
                console.log(res)
                setBlog(res.data)
                setFlag(!flag)
            })
            .catch((err) => console.error(err));

        //----------userInfo----------
        axios
            .get("http://localhost:8000/api/user/" + userId)
            .then((res) => {
                setUser(res.data)
                console.log(res.data)

            })
            .catch((err) => console.error(err));

    }, []);


    return (
        <>
            <LoginNav />
            <div className="body">
                <div className='container pt-5 col-7 '>
                    <div className='form-border'>
                        {(userId !== null) ?
                            <div className='container mt-5'>

                                <img className='img-rounded mb-4' src={blog.image} alt="" style={{ "width": "600px", "height": "300px", "border-radius": "25px" }}></img>
                                <h2 className="text-capitalize font-weight-bold">{blog.title}</h2>
                                <hr />
                                {/* <div>{blog.category}</div> */}
                                <div className="mb-4 font-weight-normal">{blog.article}</div>

                            </div>
                            :
                            <div> Login To Read More
                                <div><Link to="/login" className="btn btn-outline-primary rounded-pill ms-2 mt-4">Login</Link></div>
                            </div>
                        }
                    </div>
                </div>
            </div>
        </>
    );
};


export default BlogDetailes