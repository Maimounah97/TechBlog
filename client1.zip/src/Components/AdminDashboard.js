import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useHistory, useParams } from "react-router-dom";
import '../Styles/AdminDashboard.css';
import AOS from 'aos'
import 'aos/dist/aos.css'
import {
    BrowserRouter,
    Switch,
    Route,
    Link
} from "react-router-dom";
import LoginNav from './LoginNav'

const AdminDashboard = (props) => {
    AOS.init({ duration: 3000 });
    const [blogs, setBlogs] = useState([]);
    const [slides, setSlides] = useState([]);
    const history = useHistory();
    const userId = localStorage.getItem("userId")
    const [user, setUser] = useState({});
    const [userRole, setUserRole] = useState();


    useEffect(() => {
        //----------userInfo----------
        axios.get("http://localhost:8000/api/user/" + userId)
            .then((res) => {
                setUser(res.data)
                console.log(res.data.role)
                setUserRole(res.data.role)
            })
            .catch((err) => console.error(err));

    }, []);
    //get all blogs
    useEffect(() => {
        axios.get('http://localhost:8000/api/blogs')
            .then(res => {
                console.log("blogs from api")
                console.log(res.data)
                setBlogs(res.data.blogs)
            });
    }, [])

    //get all slides
    useEffect(() => {
        axios.get("http://localhost:8000/api/slide")
            .then((res) => {
                console.log(res.data.slide);
                setSlides(res.data.slide);
                console.log(slides);
            })
            .catch((err) => console.error(err));
    }, []);

    //--------------------delete blog-----------------------

    const removeBlogFromDom = (blogId) => {
        setBlogs(blogs.filter(blog => blog._id != blogId))
    }
    const deleteBlog = (blogId) => {
        console.log("delete button clicked")
        axios.delete('http://localhost:8000/api/blog/' + blogId)
            .then(res => {
                removeBlogFromDom(blogId)

            })
    }

    //------------------delete image--------------------------

    const removeSlideFromDom = (slideId) => {
        setSlides(slides.filter(slide => slide._id != slideId))
    }
    const deleteSlide = (slideId) => {
        console.log("delete button clicked")
        axios.delete('http://localhost:8000/api/image/' + slideId)
            .then(res => {
                removeSlideFromDom(slideId)

            })
    }
    return (
        <>
            <LoginNav />

            <div className='body container'>
                {(userRole == "admin") ?
                    <>
                        <div className='title fs-2 fw-bold'>Admin Dashboard
                            <hr />
                        </div>

                        <div data-aos="fade-up" className='blogsTable'>
                            <div className='row'>
                                <div className='col-6 text-start'>
                                    <h3>Blogs Table</h3>

                                </div>
                                <div className='col-3 text-end '>
                                    <button onClick={(e) => { history.push('/addBlog') }} className="btn btn-success rounded-pill">
                                        Add Blog
                                    </button>
                                </div>

                            </div>
                            <hr />



                            <table className="table table-dark table-sm table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">Blog Title</th>
                                        <th scope="col">Blog Category</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody >
                                    {blogs.map((blog, i) =>

                                        <tr key={i}>
                                            <td className='test'><p className=''>{blog.title}</p></td>
                                            <td><p className=''>{blog.category}</p></td>
                                            <td><button onClick={(e) => { deleteBlog(blog._id) }} className="me-3 btn btn-danger rounded-pill">
                                                Delete
                                            </button>
                                                <button onClick={(e) => { history.push('/blog/' + blog._id + '/edit') }} className="me-3 btn btn-warning rounded-pill">
                                                    Edit
                                                </button>
                                            </td>
                                        </tr>


                                    )}
                                </tbody>
                            </table>
                        </div>
                        <div className='row'>
                            <div className='col-6 text-start'>
                                <h3>Slide Table</h3>

                            </div>
                            <div className='col-3 text-end '>
                                <button onClick={(e) => { history.push('/addImageInSlider') }} className=" btn btn-success rounded-pill">
                                    Add Slide
                                </button>
                            </div>

                        </div>
                        <hr />
                        <div data-aos="fade-up" className='slidesTable'>
                            <table className="table table-sm table-dark table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">Slide Title</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody >
                                    {slides.map((slide, i) =>

                                        <tr key={i}>
                                            <td><p className=''>{slide.title}</p></td>
                                            <td><button onClick={(e) => { deleteSlide(slide._id) }} className="me-3 btn btn-danger rounded-pill">
                                                Delete
                                            </button></td>
                                        </tr>


                                    )}
                                </tbody>
                            </table>
                        </div>
                    </>
                    :
                    <div className='test-light'> For authorized users only
                        <div><Link to="/" className="btn btn-outline-secondary rounded-pill ms-2 mt-4">Back to HOME</Link></div>
                    </div>
                }
            </div>
        </>
    )
}

export default AdminDashboard;