import React, { useState, useEffect } from 'react'
import { Link } from "react-router-dom";
import axios from "axios";
import AOS from 'aos'
import 'aos/dist/aos.css'
import '../Styles/Card.css';



const Card = (props) => {

    useEffect(() => {
        AOS.init({ duration: 3000 })
    }, [])
    return (
        <>
            {/* <h3 className='cards-header' >Sections</h3> */}
            <div data-aos="fade-up" className="col-sm-6">
                <div className="card Bcard p-3 mb-5rounded m-3 bg-dark text-whit">
                    <img src={props.image} className="card-img-top" alt="..." />
                    <div className="card-body">
                        <h5 className="card-title">{props.title}</h5>
                        <hr />
                        <p className="card-text">{props.summary}</p>
                        <Link to={'/blog/' + props.blogId}><button className='btn btn-warning rounded-pill mt-5'>Read More</button>  </Link>
                    </div>
                </div>
            </div>


        </>
    )
}

export default Card
