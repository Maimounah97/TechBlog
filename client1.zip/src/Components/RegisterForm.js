import React, { useState } from "react";
import axios from "axios";
import { Link, useHistory } from "react-router-dom";
import regBg from '../assets/reg-bg3.jpg';
import '../Styles/Register.css';
import LoginNav from "./LoginNav";


const RegisterForm = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  // to register admin uncomment line 15 and comment line 16
  // const [role, setRole] = useState("admin");
  const [role, setRole] = useState("");
  const [errors, setErrors] = useState([]);
  const history = useHistory();

  const onSubmitHandler = (e) => {
    //prevent default behavior of the submit
    e.preventDefault();
    //make a post request to create a new user
    axios
      .post("http://localhost:8000/api/signup", {
        name,
        email,
        password,
        confirmPassword,
        role

      })
      .then((res) => {
        console.log(res);
        console.log(res.data.role)

        // history.push("/")

      })
      .catch((err) => {
        const data = err.response.data;
        console.log(data);
        const errorMessages = [];
        if ("errors" in data) {
          for (let field in data.errors) {
            const validationError = data.errors[field];
            errorMessages.push(validationError.message);
          }
        }
        setErrors(errorMessages);
      });
  };

  return (
    <>
      <LoginNav />
      <img className="imageBack" src={regBg} alt="" />
      <div className="body">
        {errors.map((errorMessage, index) => (
          <ul key={index} >
            <div className="alert alert-warning container" role="alert">{errorMessage}</div>
          </ul>
        ))}
        <div className="register-box">
          <form onSubmit={onSubmitHandler} >
            <div className='container  col-5 '>
              <div className='text-start text-light'>
                <h3 className="text-center text-warning" >Register Form</h3>
                <div className="row">
                  <div className="col ">
                    <p>
                      Name:
                      <input
                        type="text"
                        onChange={(e) => setName(e.target.value)}
                        value={name}
                        className="form-control"
                      />
                    </p>
                    <p>
                      Email:
                      <input
                        type="text"
                        onChange={(e) => setEmail(e.target.value)}
                        value={email}
                        className="form-control"
                      />
                    </p>
                    <p>
                      Password:
                      <input
                        type="password"
                        onChange={(e) => setPassword(e.target.value)}
                        value={password}
                        className="form-control"
                      />
                    </p>
                  </div>
                  <div>
                    <div>
                      <label>Confirm Password:</label>
                      <input
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        value={confirmPassword}
                        type="password"
                        className="form-control"
                      />
                    </div>
                  </div>
                </div>
                <button type="submit"
                  className="btn btn-light rounded-pill mt-3">
                  Sign Up
                </button>
                <p className="text-light text-start">you already have account? <Link to={"/logIn"} className="text-warning" >Login</Link></p>
              </div>
            </div>
          </form>

        </div>

      </div>
    </>
  )
}
export default RegisterForm;